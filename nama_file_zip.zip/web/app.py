from flask import Flask, render_template, request

app = Flask(__name__)

import pandas as pd
from sklearn.linear_model import LinearRegression

# Membaca data dan melatih model
data = pd.read_csv('Student_Performance.csv')
data['Extracurricular Activities'] = data['Extracurricular Activities'].map({'Yes': 1, 'No': 0})
X = data[['Hours Studied', 'Previous Scores', 'Extracurricular Activities', 'Sleep Hours', 'Sample Question Papers Practiced']]
y = data['Performance Index']
model = LinearRegression()
model.fit(X, y)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        hours_studied = float(request.form['hours_studied'])
        previous_scores = float(request.form['previous_scores'])
        extracurricular_activities = int(request.form['extracurricular_activities'])
        sleep_hours = float(request.form['sleep_hours'])
        sample_question_papers_practiced = float(request.form['sample_question_papers_practiced'])

        data_to_predict = {
            'Hours Studied': [hours_studied],
            'Previous Scores': [previous_scores],
            'Extracurricular Activities': [extracurricular_activities],
            'Sleep Hours': [sleep_hours],
            'Sample Question Papers Practiced': [sample_question_papers_practiced]
        }
        data_to_predict_df = pd.DataFrame(data_to_predict)

        predicted_performance_index = model.predict(data_to_predict_df)

        return render_template('index.html', prediction=predicted_performance_index[0])

if __name__ == '__main__':
    app.run(debug=True)